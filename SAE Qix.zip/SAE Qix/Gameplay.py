#   * - * - * - * - * - * - * - * - * - * - * - * - * - * - * - * - * - *
#   *                                                                   *
#   *                              Imports                              *
#   *                                                                   *
#   * - * - * - * - * - * - * - * - * - * - * - * - * - * - * - * - * - *

from fltk import *
from Calculs import *
from Interface import *
from random import randint, choice
from math import sin, pi
import time

#   * - * - * - * - * - * - * - * - * - * - * - * - * - * - * - * - * - *
#   *                                                                   *
#   *                             Fonctions                             *
#   *                                                                   *
#   * - * - * - * - * - * - * - * - * - * - * - * - * - * - * - * - * - *


def test_perte(cd_debut: list, cd_joueur: list, cd_QIX: list, cote: float, lst_joueur: list) -> bool :
    """Renvoie True si le joueur rentre dans sa trainée ou si le QIX rentre dans la trainée du joueur. Dans le cas contraire, renvoie False."""
    if cd_debut == cd_joueur :
        return True
    for element in lst_joueur :
        if encadrement(cd_QIX[0],element[0],cd_QIX[0]+cote,True,True) :
            if encadrement(cd_QIX[1],element[1],cd_QIX[1] + cote,True,True) :
                return True
        if cd_joueur == element :
            return True
    return False


def test_sortie_safezone(lst_safezone: list, cx: int, cy: int, dx: int, dy: int, dep: int) -> list :
    """Renvoie les coordonnées du point où le joueur est sorti de la safezone. Si le joueur ne sort pas de la safezone, renvoie une liste vide."""
    for i in range (1,len(lst_safezone)-1) :

        if cx - dx == lst_safezone[i][0] and cy - dy == lst_safezone[i][1] :
            if  ((encadrement_deux_sens(lst_safezone[i-1][0],cx,lst_safezone[i][0],True,True) and encadrement_deux_sens(lst_safezone[i-1][1],cy,lst_safezone[i][1],True,True))
            or  (encadrement_deux_sens(lst_safezone[i][0],cx,lst_safezone[i+1][0],True,True) and encadrement_deux_sens(lst_safezone[i][1],cy,lst_safezone[i+1][1],True,True))) :
                    return []
            else :
                return [cx - dx, cy - dy]
          
        if cy - dy == lst_safezone[i][1] :
            if encadrement_deux_sens(lst_safezone[i][0],cx-dx,lst_safezone[i+1][0],False,False) :
                if cy == lst_safezone[i][1] + dep or cy == lst_safezone[i][1] - dep :
                    return [cx - dx, cy - dy]
                    
        elif cx - dx == lst_safezone[i][0] :
            if encadrement_deux_sens(lst_safezone[i][1],cy-dy,lst_safezone[i+1][1],False,False) :
                if cx == lst_safezone[i][0] + dep or cx == lst_safezone[i][0] - dep :
                    return [cx - dx, cy - dy]
          
    return []


def test_entree_safezone(lst_safezone: list, cx: int, cy: int) -> bool :
    """Renvoie True si le joueur rentre dans la safezone."""
    for i in range (len(lst_safezone)-1) :
        if (encadrement_deux_sens(lst_safezone[i][0],cx,lst_safezone[i+1][0],True,True)) and cy == lst_safezone[i][1] :
            return True
        
        elif (encadrement_deux_sens(lst_safezone[i][1],cy,lst_safezone[i+1][1],True,True)) and cx == lst_safezone[i][0] :
            return True
    return False


def test_interieur_safezone(lst_coordonnees: list, cx: float, cy: float) -> bool :
    """Test pour savoir si un point est à l'intérieur d'une liste de coordonnées (lst_coordonnees doit être une matrice avec des listes à l'intérieur de taille différentes)"""
    nb = 0
    for i in range (len(lst_coordonnees)) :
        for j in range (len(lst_coordonnees[i])) :
            if lst_coordonnees[i][j][0] > cx :
                continue
            if j == len(lst_coordonnees[i])-1 :
                if encadrement_deux_sens(lst_coordonnees[i][j][1],cy,lst_coordonnees[i][0][1],True,False) :
                    nb += 1
            else :
                if encadrement_deux_sens(lst_coordonnees[i][j][1],cy,lst_coordonnees[i][j+1][1],True,False) :
                    nb += 1
    if nb % 2 == 0 :
        return False
    else :
        return True
    

def creation_obstacles(nb_obstacles: int) -> list :
    """Crée nb_obstacles obstacles et renvoie la liste avec leurs coordonnées."""
    lst_obstacles = []
    nb_cases_abs = (coin_inf_droite[0] - coin_sup_gauche[0]) // 10
    nb_cases_ord = (coin_inf_droite[1] - coin_sup_gauche[1]) // 10
    for i in range(nb_obstacles) :
        obstacle = [randint(2, nb_cases_abs-2), randint(2, nb_cases_ord-2)]
        while obstacle in lst_obstacles :
            obstacle = [randint(2, nb_cases_abs-2), randint(2, nb_cases_ord-2)]
        obstacle[0] = obstacle[0] * 10 + coin_sup_gauche[0]
        obstacle[1] = obstacle[1] * 10 + coin_sup_gauche[1]
        lst_obstacles.append(obstacle)
        carre(lst_obstacles[i][0], lst_obstacles[i][1], 10, "orange", "orange", "obstacles", 1)
    return lst_obstacles


def creation_pommes(nb_pommes: int) -> list :
    """docstring"""
    lst_pommes = []
    nb_cases_abs = (coin_inf_droite[0] - coin_sup_gauche[0]) // 10
    nb_cases_ord = (coin_inf_droite[1] - coin_sup_gauche[1]) // 10
    for i in range(nb_pommes) :
        pomme = [randint(2, nb_cases_abs-2), randint(2, nb_cases_ord-2)]
        while pomme in lst_pommes :
            pomme = [randint(2, nb_cases_abs-2), randint(2, nb_cases_ord-2)]
        pomme[0] = pomme[0] * 10 + coin_sup_gauche[0]
        pomme[1] = pomme[1] * 10 + coin_sup_gauche[1]
        lst_pommes.append(pomme)
        image(lst_pommes[i][0], lst_pommes[i][1], os.path.join(path,'apple.gif'), ancrage="center",tag="apple")
    return lst_pommes


def mouvement_sparx(cxSparx: float, cySparx: float, cw: bool, last: str) :   
    """Permet d'établir le prochain déplacement du sparx, et renvoie le déplacement à réalisé (x et y) ainsi la direction vers laquelle il se dirige."""
    dxSparx, dySparx = 0, 0
    
    # - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

    haut = coin_sup_gauche[1]       # Coordonnée Y de la limite supérieure de la Zone de Jeu
    bas = coin_inf_droite[1]        # Coordonnée Y de la limite inférieure de la ZdJ
    gauche = coin_sup_gauche[0]     # Coordonnée X de la limite latérale gauche de la ZdJ
    droite = coin_inf_droite[0]     # Coordonnée X de la limite latérale droite de la ZdJ

    # Vieux code, qui est au moins un peu fonctionnel, comme le nouveau ne l'est pas à cause de problèmes dans la définition des polygones

    if cySparx == haut :
        if cxSparx == droite and cw :
            dySparx = depSparx
            last = "down"
        elif cxSparx == gauche and cw is False :    # Pour (cw is False), je met l'inverse des instructions, comme celles-ci
            dySparx = -depSparx                     # seront inversés par la suite
            last = "up"
        else :
            dxSparx = depSparx
            last = "right"

    elif cxSparx == droite :
        if cySparx == bas and cw :
            dxSparx = -depSparx
            last = "left"
        elif cySparx == haut and cw is False :
            dySparx = depSparx
            last = "haut"
        else :
            dySparx = depSparx
            last = "down"

    elif cySparx == bas :
        if cxSparx == gauche and cw :
            dySparx = -depSparx
            last = "up"
        elif cxSparx == droite and cw is False :
            dySparx = depSparx
            last = "down"
        else :
            dxSparx = -depSparx
            last = "left"

    elif cxSparx == gauche :
        if cySparx == haut and cw :
            dxSparx = depSparx
            last = "right"
        elif cySparx == bas and cw is False :
            dxSparx = -depSparx
            last = "left"
        else :
            dySparx = -depSparx
            last = "up"

    if (cw is False) :                                             # Si tourne dans sens inverse des aiguilles d'une montre
        if last == "left" :
            last = "right"
        elif last == "right" :
            last = "left"
        elif last == "up" :
            last = "down"
        elif last == "down" :
            last = "up"
        return -dxSparx, -dySparx, last
        
    return dxSparx, dySparx, last
#     zone_jeu = [coin_sup_gauche,[coin_inf_droite[0],coin_sup_gauche[1]],coin_inf_droite,[coin_sup_gauche[0],coin_inf_droite[1]]]
#     dxSparx, dySparx = 0, 0     # Déplacements à ajouter aux coordonnées du sparx
#    # - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
#     pos = list()
#     liste = list()
#     for i in lst_coordonnees_safezone:
#         if i not in liste :
#             liste.append(i)

#     tolerance = depSparx/2
#     a = 0
#     for coor in lst_coordonnees_safezone :
#         if abs(coor[0]-cxSparx) <= tolerance and abs(coor[1]-cySparx) <= tolerance and cw :
#             pos = liste[a+1] if a+1 < len(liste) else liste[0]
#             # print(a)

#         elif abs(coor[0]-cxSparx) <= tolerance and abs(coor[1]-cySparx) <= tolerance and (cw is False):
#             pos = liste[len(liste)-1] if a-1 >= 0 else liste[a-1]
#             # print(a)

#         a += 1

#     if len(pos) >= 1 :
#         # print(pos)
#         if pos[0] >= cxSparx :
#             dxSparx += depSparx
#             last = 'Right'
#         elif pos[0] <= cxSparx :
#             dxSparx += -depSparx
#             last = 'Left'
#         if pos[1] >= cySparx :
#             dySparx += depSparx
#             last = 'Down'
#         elif pos[1] <= cySparx :
#             dySparx += -depSparx
#             last = 'Up'

#     else :
#         if last == 'Right' :
#             dxSparx += depSparx 
#         elif last == 'Left' :
#             dxSparx += -depSparx
#         elif last == 'Up' :
#             dySparx += -depSparx
#         elif last == 'Down' :
#             dySparx += depSparx

    return dxSparx, dySparx, last


def mouvement_sparx_interne(cxSparx: float, cySparx: float, cw: bool, last: str) :   
    """Permet d'établir le prochain déplacement du sparx (pour la variante interne), et renvoie le déplacement à réalisé (x et y) ainsi la direction vers laquelle il se dirige."""

    return mouvement_sparx(cxSparx, cySparx, cw, last)
# le code ne fonctionne pas à cause de problèmes provenant d'autres fonctions

#     zone_jeu = [coin_sup_gauche,[coin_inf_droite[0],coin_sup_gauche[1]],coin_inf_droite,[coin_sup_gauche[0],coin_inf_droite[1]]]
#     dxSparx, dySparx = 0, 0     # Déplacements à ajouter aux coordonnées du sparx
#    # - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
#     pos = list()
#     for poly in lst_coordonnees_polygones :

#         if cw and poly == zone_jeu:
#             for m in range(len(poly)):
#                 if poly[m][0] == cxSparx and poly[m][1] == cySparx :
#                     pos = poly[0] if m+1 >= len(poly) else poly[m+1]

#         elif cw is False and poly == zone_jeu:
#             for n in range(len(poly)):
#                 if poly[n][0] == cxSparx and poly[n][1] == cySparx :
#                     pos = poly[len(poly)-1] if n-1 < 0 else poly[n-1]

#         elif cw :     # Remonte la liste (comme les coordonnées des sommets des polygones sont classés dans le sens des aiguilles d'une montre)
#             for i in range(len(poly)):
#                 if poly[i][0] == cxSparx and poly[i][1] == cySparx :
#                     pos = poly[len(poly)-1] if i-1 < 0 else poly[i-1]

#         else :      # Avance dans la liste
#             for j in range(len(poly)):
#                 if poly[j][0] == cxSparx and poly[j][1] == cySparx :
#                     pos = poly[0] if j+1 >= len(poly) else poly[j+1]

#     if len(pos) >= 1 :
#         destination = choice(pos)
#         if destination[0] > cxSparx :
#             dxSparx += depSparx
#             last = 'Right'
#         elif destination[0] < cxSparx :
#             dxSparx += -depSparx
#             last = 'Left'
#         elif destination[1] > cySparx :
#             dySparx += depSparx
#             last = 'Down'
#         elif destination[1] < cySparx :
#             dySparx += -depSparx
#             last = 'Up'

#     else :
#         if last == 'Right' :
#             dxSparx += depSparx 
#         elif last == 'Left' :
#             dxSparx += -depSparx
#         elif last == 'Up' :
#             dySparx += -depSparx
#         elif last == 'Down' :
#             dySparx += depSparx

#     return dxSparx, dySparx, last

def bornage(x: float,y: float, n: int=0):
    """Vérifie que les coordonées données en paramètre sont bien dans l'espace de jeu, et limite alors celles-ci dans le cas contraire (avec, si besoin un décalage)."""
    x = max(x,coin_sup_gauche[0]-n)
    x = min(x,coin_inf_droite[0]+n)
    y = max(y,coin_sup_gauche[1]-n)
    y = min(y,coin_inf_droite[1]+n)
    return x,y



#   * - * - * - * - * - * - * - * - * - * - * - * - * - * - * - * - * - *
#   *                                                                   *
#   *                           Code Principal                          *
#   *                                                                   *
#   * - * - * - * - * - * - * - * - * - * - * - * - * - * - * - * - * - *

if __name__ == "__main__" :

    #   * - * - * - * - * - * - * - * - * - * - * - * - * - * - * - * - * - *
    #   *                                                                   *
    #   *                               Menu                                *
    #   *                                                                   *
    #   * - * - * - * - * - * - * - * - * - * - * - * - * - * - * - * - * - *

    cree_fenetre(largeurFenetre, hauteurFenetre)
    lst_variantes = []
    # les variables dans l'ordre :
    #           obstacles, pommes, vies, nivInit, vitLent, vitRap, vitQIX, vitSp, aCapt, QIXSize, PlayerSize, vitQIX+, vitSp+, niv+, aCapt+
    lst_options = ["5",     "3",   "3",   "1",      "5",    "10",   "3",   "0.75", "75",  "10",      "10",    "0.25", "0.125", "5",   "1"]
    
    # les variables dans l'ordre :
    #           monter1, gauche1, bas1,  droite1,  lent1,    rapide1, monter2, gauche2, bas2, droite2, lent2, rapide2
    lst_touches = ["Up", "Left", "Down", "Right", "Return",   "m",      "z",      "q",    "s",   "d",    "a",    "e"]
    variable = menu_principal(largeurFenetre, hauteurFenetre, path)
    while variable != None :
        efface_tout()
        if variable == "Principal" :
            variable = menu_principal(largeurFenetre, hauteurFenetre, path)
        elif variable == "Variantes" :
            variable, lst_variantes = menu_variantes(largeurFenetre, hauteurFenetre, path, lst_variantes)
        elif variable == "Parametres" :
            while variable != None and variable != "Principal" :
                efface_tout()
                if variable == "Parametres" :
                    variable = menu_parametres(largeurFenetre, hauteurFenetre, path)
                elif variable == "Options" :
                    variable, lst_options = menu_options(largeurFenetre, hauteurFenetre, path, lst_options)
                elif variable == "Touches" :
                    variable, lst_touches = menu_touches(largeurFenetre, hauteurFenetre, path, lst_touches)
        elif variable == "Commencer" :
            efface_tout()
            break
    
    if variable == None :
        ferme_fenetre()
    else :
        for i in range(len(lst_options)) :
            if "." in lst_options[i] :
                lst_options[i] = float(lst_options[i])
            else :
                lst_options[i] = int(lst_options[i])

    #   * - * - * - * - * - * - * - * - * - * - * - * - * - * - * - * - * - *
    #   *               Mise en place des différents éléments               *
    #   * - * - * - * - * - * - * - * - * - * - * - * - * - * - * - * - * - *



    #   ========= Définition de la zone de jeu =========

        zonetot = 0     # Ratio entre les zones capturées par les joueurs et le terrain de jeu
        nbVies = lst_options[2]
        niveau = lst_options[3]
        zone_a_capture = lst_options[8] + lst_options[-1] * (niveau // lst_options[-2])
        score = 0 if "Score" in lst_variantes else None

        coin_sup_gauche, coin_inf_droite = ecran_launch(zonetot, zone_a_capture, nbVies, niveau, score, lst_variantes)

        Perdu = False
        Perdu2 = False
        dessiner = False
        dessiner2 = False
        nb_delai = 10                   
        # Nombre qui indique le délai entre les déplacements du QIX

        a = 0
        # Nombre qui incrémente à chaque exécution d'une boucle

        cx, cy, rayon = largeurFenetre // 2, coin_inf_droite[1], lst_options[10] // 2   #  -   -   -   -   -   -   -   Taille et position du curseur
        curseur(cx, cy, rayon)


    #   ========= Définition du Qix =========
        


        cxQIX, cyQIX = largeurFenetre // 2, (coin_inf_droite[1] - coin_sup_gauche[1]) / 4 + coin_sup_gauche[1]
        carre(cxQIX - lst_options[9] // 2, cyQIX - lst_options[9] // 2, lst_options[9],"Red","Red","QIX",None)


    #   ========= Définition des Sparx =========

        SPARX = dict()
        direc = ['Right','Left']
        nb_SPARX = 2
        k = 0
        bascule = True
        for i in range(nb_SPARX) :
            if i%2 == 0 :
                k += 50
            else :
                k = -k
            SPARX[i] = [(largeurFenetre // 2)+k, coin_sup_gauche[1], direc[i%2], bascule]
            sparx(SPARX[i][0], SPARX[i][1])
            bascule = not bascule


    #   ========= Liste des coordonnées =========

        lst_coordonnees_curseur = []
        # Liste des coordonnées des cases où le curseur est passé

        lst_coordonnees_safezone = [[coin_inf_droite[0],coin_sup_gauche[1]],coin_sup_gauche,[coin_sup_gauche[0],coin_inf_droite[1]],coin_inf_droite,[coin_inf_droite[0],coin_sup_gauche[1]],coin_sup_gauche]
        # Liste des sommets que le joueur n'a pas encore capturé

        lst_coordonnees_polygones = [[coin_sup_gauche,[coin_inf_droite[0],coin_sup_gauche[1]],coin_inf_droite,[coin_sup_gauche[0],coin_inf_droite[1]]]]
        # Coordonnées des différents polygones formés par le joueur

        coordonnees_debut = []
        # Coordonnée de la case où le joueur sort de la bordure

        coordonnees_supprime = None
        # Coordonnées qui sont supprimées de la safezone lors de l'exécution de la fonction concatenation_safezone

        coordonnees_debut_safezone = [[coin_inf_droite[0],coin_sup_gauche[1]],coin_sup_gauche]
        # Coordonnées au début (ou à la fin) de la safezone uniquement utile pour la fonction debut_egal_fin

        if "Obstacles" in lst_variantes :
            lst_obstacles = creation_obstacles(lst_options[0])

        # Coordonnées des obstacles

        if "Bonus" in lst_variantes :
            lst_pommes = creation_pommes(lst_options[1])


        zonemax = aire([[coin_inf_droite[0],coin_sup_gauche[1]],coin_sup_gauche,[coin_sup_gauche[0],coin_inf_droite[1]],coin_inf_droite,[800,175],coin_sup_gauche], True)
        # Aire total de la zone de jeu

        dep = lst_options[4]
        # Vitesse de déplacement du Joueur

        depQIX = lst_options[6] #+ lst_options[11] * (niveau - 1)
        # Vitesse de déplacement du QIX

        depSparx = lst_options[7] #+ lst_options[12] * (niveau - 1)
        # Vitesse de déplacement des Sparx

        obstacle = False

        zone_p1, zone_p2 = 0,0

        if 'Joueurs' in lst_variantes :
            nbVies2 = lst_options[2]
            dep2 = lst_options[4]
            efface("curseur")
            cx, cy, rayon = coin_sup_gauche[0], coin_inf_droite[1], lst_options[10] // 2   #   -   -   -   Premier Joueur
            curseur(cx, cy, rayon)
            cx2, cy2 = coin_inf_droite  #   -   -   -   -   -   -   -   -   -   Second Joueur
            curseur2(cx2, cy2, rayon)
            lst_coordonnees_curseur2 = []
            coordonnees_debut2 = []


    #   .   .   .   .   .   Variables à initialiser .   .   .   .   .


        back,limite_d = "",""
        b = 0
        last1, last2 = "",""        


    #   * - * - * - * - * - * - * - * - * - * - * - * - * - * - * - * - * - *
    #   *                                Qix                                *
    #   * - * - * - * - * - * - * - * - * - * - * - * - * - * - * - * - * - *


        # Les déplacements seront changés, pas assez aléatoire et le Qix a tendance à ne pas beaucoup bouger d'un endroit

        # Pour le QIX, je peux choisir un point qui est alors la destination (se trouvant dans la zone non capturée), et le QIX doit alors se déplacer vers ce point. Il faut que ce point soit accessible en une ligne droite continue.

        while True :
            if a % nb_delai == 0 :
                a = 0
                dxQIX = 0
                dyQIX = 0
                change = 15
                b += 1
                card = ["nord","sud","est","ouest"]
                if b%change == 0 :         # Choisis la direction aléatoirement
                    b = 0
                    limite_d = card[randint(0,3)]

                if change is False :    # Inverse le booléen "change"
                    change = True
                else :
                    change = False

                for i in range(randint(1, 10)) :
                    x = randint(0, 6)

                    # voir à modifier le déplacement du qix avec du sin et du pi
                    if x == 1 :
                        if limite_d == "nord" :
                            dyQIX = max(-depQIX, coin_sup_gauche[1]-10 - cyQIX)                       # Déplacement -> Nord
                        if limite_d == "sud" :
                            dyQIX = min(depQIX, coin_inf_droite[1]+10 - cyQIX)                        # Déplacement -> Sud
                        if limite_d == "est" :
                            dxQIX = min(depQIX, coin_inf_droite[0]+10 - cxQIX)                        # Déplacement -> Est
                        if limite_d == "ouest" :
                            dxQIX = max(-depQIX, coin_sup_gauche[0]-10 - cxQIX)                       # Déplacement -> Ouest
                    elif x == 2 :
                        if limite_d != "nord" or limite_d == "est" :
                            dxQIX = round(min(sin(pi/4)*depQIX, coin_inf_droite[0]+10 - cxQIX))       # Déplacement -> Nord-Est
                            dyQIX = round(max(-sin(pi/4)*depQIX, coin_sup_gauche[1]-10 - cyQIX))
                        if limite_d == "sud" or limite_d == "ouest" :
                            dxQIX = round(max(-sin(pi/4)*depQIX, coin_sup_gauche[0]-10 - cxQIX))      # Déplacement -> Sud-Ouest
                            dyQIX = round(min(sin(pi/4)*depQIX, coin_inf_droite[1]+10 - cyQIX))
                    elif x == 3 :
                        if limite_d == "nord" or limite_d == "ouest" :
                            dxQIX = round(max(-sin(pi/4)*depQIX, coin_sup_gauche[0]-10 - cxQIX))      # Déplacement -> Nord-Ouest
                            dyQIX = round(max(-sin(pi/4)*depQIX, coin_sup_gauche[1]-10 - cyQIX))
                        if limite_d == "sud" or limite_d == "est" :
                            dxQIX = round(min(sin(pi/4)*depQIX, coin_inf_droite[0]+10 - cxQIX))       # Déplacement -> Sud-Est
                            dyQIX = round(min(sin(pi/4)*depQIX, coin_inf_droite[1]+10 - cyQIX))
                    if cxQIX + dxQIX > coin_inf_droite[0]-lst_options[9] or cxQIX + dxQIX < coin_sup_gauche[0]+lst_options[9] or cyQIX + dyQIX > coin_inf_droite[1]-lst_options[9] or cyQIX + dyQIX < coin_sup_gauche[1]+lst_options[9] :
                        break
                    
                    if dxQIX != 0 or dyQIX != 0 :
                        if test_interieur_safezone([lst_coordonnees_safezone],cxQIX,cyQIX):
                            cxQIX += -dxQIX
                            cyQIX += -dyQIX
                            efface("QIX")
                            carre(cxQIX - lst_options[9] // 2, cyQIX - lst_options[9] // 2, lst_options[9],"Red","Red","QIX",None)

                        else :
                            cxQIX += dxQIX
                            cyQIX += dyQIX
                            efface("QIX")
                            carre(cxQIX - lst_options[9] // 2, cyQIX - lst_options[9] // 2, lst_options[9],"Red","Red","QIX",None)
                        

                    


    #   * - * - * - * - * - * - * - * - * - * - * - * - * - * - * - * - * - *
    #   *                               Sparx                               *
    #   * - * - * - * - * - * - * - * - * - * - * - * - * - * - * - * - * - *


            efface("Sparx")
            for i in SPARX.keys() :
                if "Sparx" in lst_variantes :
                    dxSparx, dySparx, SPARX[i][2] = mouvement_sparx_interne(SPARX[i][0], SPARX[i][1], SPARX[i][3], SPARX[i][2])
                else :
                    dxSparx, dySparx, SPARX[i][2] = mouvement_sparx(SPARX[i][0], SPARX[i][1], SPARX[i][3], SPARX[i][2])

                SPARX[i][0] += dxSparx
                SPARX[i][1] += dySparx
                SPARX[i][0], SPARX[i][1] = bornage(SPARX[i][0], SPARX[i][1])
                sparx(SPARX[i][0], SPARX[i][1])


    #   * - * - * - * - * - * - * - * - * - * - * - * - * - * - * - * - * - *
    #   *                              Joueur                               *
    #   * - * - * - * - * - * - * - * - * - * - * - * - * - * - * - * - * - *


            ev = donne_ev()
            tev = type_ev(ev)
            dx = 0
            dy = 0
            dx2 = 0
            dy2 = 0

            if touche_pressee(lst_touches[1]):
                dx = max(-dep, coin_sup_gauche[0] - cx)
            elif touche_pressee(lst_touches[3]):
                dx = min(dep, coin_inf_droite[0] - cx)
            elif touche_pressee(lst_touches[2]):
                dy = min(dep, coin_inf_droite[1] - cy)
            elif touche_pressee(lst_touches[0]):
                dy = max(-dep, coin_sup_gauche[1] - cy)
    #   -   -   -   -   -   -   -   -   -   Joueur 2    -   -   -   -   -   -   -   -   -
            if "Joueurs" in lst_variantes :
                if touche_pressee(lst_touches[7]):
                    dx2 = max(-dep2, coin_sup_gauche[0] - cx2)
                elif touche_pressee(lst_touches[9]):
                    dx2 = min(dep2, coin_inf_droite[0] - cx2)
                elif touche_pressee(lst_touches[8]):
                    dy2 = min(dep2, coin_inf_droite[1] - cy2)
                elif touche_pressee(lst_touches[6]):
                    dy2 = max(-dep2, coin_sup_gauche[1] - cy2)
    #   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -
                
            if touche_pressee(lst_touches[5]) and "Vitesse" in lst_variantes :
                if coordonnees_debut == [] :
                    dep = lst_options[5]
                    draw(2, lst_variantes)
                    dessiner = True
            
            if touche_pressee(lst_touches[4]) :
                if coordonnees_debut == [] :
                    dep = lst_options[4]
                    draw(1, lst_variantes)
                    dessiner = True
    #   -   -   -   -   -   -   -   -   -   Joueur 2    -   -   -   -   -   -   -   -   -
            if "Joueurs" in lst_variantes:        
                if touche_pressee(lst_touches[11]) and "Vitesse" in lst_variantes :
                    if coordonnees_debut == [] :
                        dep2 = lst_options[5]
                        draw2(2)
                        dessiner2 = True
                
                if touche_pressee(lst_touches[10]) :
                    if coordonnees_debut == [] :
                        dep2 = lst_options[4]
                        draw2(1)
                        dessiner2 = True
    #   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -
                    
            if dx != 0 or dy != 0 :
                efface('curseur')
                Perdu = test_perte(coordonnees_debut, [cx+dx, cy+dy], [cxQIX-lst_options[9], cyQIX-lst_options[9]], lst_options[10], lst_coordonnees_curseur)
                cx += dx
                cy += dy

                if "Obstacles" in lst_variantes :
                    for e in lst_obstacles :
                        if encadrement_deux_sens(e[0], cx, e[0] + 10) and encadrement_deux_sens(e[1], cy, e[1]+10) :
                            cx = cx - dx
                            cy = cy - dy
                            obstacle = True
                            break

                
                if dessiner and not obstacle :
                
                    if coordonnees_debut == [] :  # Test pour savoir si le joueur est sur une bordure
                        coordonnees_debut = test_sortie_safezone(lst_coordonnees_safezone, cx, cy, dx, dy, dep)          # Test pour savoir si le joueur sort d'une bordure
                        if coordonnees_debut != [] :
                            if test_interieur_safezone([lst_coordonnees_safezone],cx,cy) :   # Test pour savoir si le joueur sort vers la zone de jeu
                                ligne(cx - dx, cy - dy, cx, cy, "Gold", tag = "Trainée")
                                lst_coordonnees_curseur.append([cx, cy])
                            else :  # Si le joueur ne va pas vers la zone de jeu, il faut annuler le mouvement
                                cx = cx - dx
                                cy = cy - dy
                                coordonnees_debut = []

                    else :
                        lst_coordonnees_curseur.append([cx, cy])
                        ligne(cx - dx, cy - dy, cx, cy, "Gold", tag = "Trainée")
                        if Perdu == True :
                            pass
                        elif test_entree_safezone(lst_coordonnees_safezone,cx,cy) :       # Test pour savoir si le joueur entre dans la safezone
                            lst_coordonnees_curseur.insert(0, coordonnees_debut)        # Insertion de la première coordonnée du polygone formé par le joueur
                            lst_coordonnees_curseur = sommets(lst_coordonnees_curseur)  # Fonction pour réduire le nombre de coordonnées dans lst_coordonnees_curseur
                            lst_coordonnees_curseur = cw_a_ccw(lst_coordonnees_curseur) # Fonction pour faire en sorte que les coordonnées du polygone formé par le joueur soit dans le sens contraine de l'aiguille d'une montre (ccw)
                            lst_coordonnees_safezone, coordonnees_supprime = concatenation_safezone(lst_coordonnees_safezone, lst_coordonnees_curseur)  # Ajout et suppression des coordonnées de la safezone

                            if coordonnees_supprime != None :   # Pour ne pas écraser les polygones précedemment faits par le joueur
                                lst_coordonnees_curseur = lst_coordonnees_curseur + coordonnees_supprime

                            couleur = "green" if dep == lst_options[4] else "dark blue"

                            if test_interieur_safezone([lst_coordonnees_safezone],cxQIX, cyQIX) :   # Si le QIX est à l'intérieur du polygone, le reste de la zone est capturé
                                polygone(lst_coordonnees_curseur, "white", couleur, tag = "ZoneC")
                                lst_coordonnees_polygones.append(lst_coordonnees_curseur)
                            else :
                                polygone(lst_coordonnees_safezone, "white", couleur, tag = "ZoneC")
                                lst_coordonnees_polygones.append(lst_coordonnees_safezone)
                                lst_coordonnees_safezone = list(lst_coordonnees_curseur)

                            lst_coordonnees_safezone, coordonnees_debut_safezone = debut_egal_fin(lst_coordonnees_safezone, coordonnees_debut_safezone) # Modification des 2 premiers ou derniers éléments de la safezone pour qu'elles soient les mêmes
                            lst_coordonnees_safezone = sommets(lst_coordonnees_safezone)

                            tempo = zonetot
                            zonetot = ((zonemax - aire(lst_coordonnees_safezone,True)) / zonemax) * 100   # Calcul de l'aire
                            if "Joueurs" in lst_variantes:
                                zone_p1 += zonetot-tempo
                            if score != None :
                                efface("score")
                                score = score + int((aire(lst_coordonnees_safezone,True)*(15-dep))//10000)
                            efface("Trainée")
                            if "Obstacles" in lst_variantes :
                                efface("obstacles")
                                for e in lst_obstacles :
                                    carre(e[0], e[1], 10, "orange", "orange", "obstacles", 1)
                            efface("Zonecapturee")
                            lst_coordonnees_curseur = []
                            coordonnees_debut = []
                            coordonnees_supprime = None
                            Perdu = False
                            update_act(zonetot, score, lst_variantes, zone_p1, zone_p2)
                curseur(cx, cy, rayon)
                if "Joueurs" in lst_variantes :
                    curseur2(cx2, cy2, rayon)
                obstacle = False

    #   -   -   -   -   -   -   -   -   -   Joueur 2    -   -   -   -   -   -   -   -   -
            if "Joueurs" in lst_variantes:                 
                if dx2 != 0 or dy2 != 0 :
                    efface('curseur')
                    Perdu2 = test_perte(coordonnees_debut2, [cx2+dx2, cy2+dy2], [cxQIX-lst_options[9], cyQIX-lst_options[9]], lst_options[10], lst_coordonnees_curseur2)
                    cx2 += dx2
                    cy2 += dy2

                    if "Obstacles" in lst_variantes :
                        for e in lst_obstacles :
                            if encadrement_deux_sens(e[0], cx2, e[0] + 10) and encadrement_deux_sens(e[1], cy2, e[1]+10) :
                                cx2 = cx2 - dx2
                                cy2 = cy2 - dy2
                                obstacle = True
                                break

                    
                    if dessiner2 and not obstacle :
                    
                        if coordonnees_debut2 == [] :  # Test pour savoir si le joueur est sur une bordure
                            coordonnees_debut2 = test_sortie_safezone(lst_coordonnees_safezone, cx2, cy2, dx2, dy2, dep2)          # Test pour savoir si le joueur sort d'une bordure
                            if coordonnees_debut2 != [] :
                                if test_interieur_safezone([lst_coordonnees_safezone],cx2,cy2) :   # Test pour savoir si le joueur sort vers la zone de jeu
                                    ligne(cx2 - dx2, cy2 - dy2, cx2, cy2, "gray", tag = "Trainée2")
                                    lst_coordonnees_curseur2.append([cx2, cy2])
                                else :  # Si le joueur ne va pas vers la zone de jeu, il faut annuler le mouvement
                                    cx2 = cx2 - dx2
                                    cy2 = cy2 - dy2
                                    coordonnees_debut2 = []

                        else :
                            lst_coordonnees_curseur2.append([cx2, cy2])
                            ligne(cx2 - dx2, cy2 - dy2, cx2, cy2, "gray", tag = "Trainée2")
                            if Perdu2 == True :
                                pass
                            elif test_entree_safezone(lst_coordonnees_safezone,cx2,cy2) :       # Test pour savoir si le joueur entre dans la safezone
                                lst_coordonnees_curseur2.insert(0, coordonnees_debut2)        # Insertion de la première coordonnée du polygone formé par le joueur
                                lst_coordonnees_curseur2 = sommets(lst_coordonnees_curseur2)  # Fonction pour réduire le nombre de coordonnées dans lst_coordonnees_curseur2
                                lst_coordonnees_curseur2 = cw_a_ccw(lst_coordonnees_curseur2) # Fonction pour faire en sorte que les coordonnées du polygone formé par le joueur soit dans le sens contraine de l'aiguille d'une montre (ccw)
                                lst_coordonnees_safezone, coordonnees_supprime = concatenation_safezone(lst_coordonnees_safezone, lst_coordonnees_curseur2)  # Ajout et suppression des coordonnées de la safezone

                                if coordonnees_supprime != None :   # Pour ne pas écraser les polygones précedemment faits par le joueur
                                    lst_coordonnees_curseur2 = lst_coordonnees_curseur2 + coordonnees_supprime

                                couleur = "orange" if dep2 == lst_options[4] else "yellow"

                                if test_interieur_safezone([lst_coordonnees_safezone],cxQIX, cyQIX) :   # Si le QIX est à l'intérieur du polygone, le reste de la zone est capturé
                                    polygone(lst_coordonnees_curseur2, "white", couleur, tag = "ZoneC")
                                    lst_coordonnees_polygones.append(lst_coordonnees_curseur2)
                                else :
                                    polygone(lst_coordonnees_safezone, "white", couleur, tag = "ZoneC")
                                    lst_coordonnees_polygones.append(lst_coordonnees_safezone)
                                    lst_coordonnees_safezone = list(lst_coordonnees_curseur2)

                                lst_coordonnees_safezone, coordonnees_debut_safezone = debut_egal_fin(lst_coordonnees_safezone, coordonnees_debut_safezone) # Modification des 2 premiers ou derniers éléments de la safezone pour qu'elles soient les mêmes
                                lst_coordonnees_safezone = sommets(lst_coordonnees_safezone)

                                tempo2 = zonetot
                                zonetot = ((zonemax - aire(lst_coordonnees_safezone,True)) / zonemax) * 100   # Calcul de l'aire
                                if "Joueurs" in lst_variantes:
                                    zone_p2 += zonetot-tempo2
                                if score != None :
                                    efface("score")
                                    score = score + int((aire(lst_coordonnees_safezone,True)*(15-dep2))//10000)
                                efface("Trainée2")
                                if "Obstacles" in lst_variantes :
                                    efface("obstacles")
                                    for e in lst_obstacles :
                                        carre(e[0], e[1], 10, "orange", "orange", "obstacles", 1)
                                efface("Zonecapturee")
                                lst_coordonnees_curseur2 = []
                                coordonnees_debut2 = []
                                coordonnees_supprime = None
                                Perdu = False
                                update_act(zonetot, score, lst_variantes, zone_p1, zone_p2)
                    curseur(cx,cy,rayon)
                    curseur2(cx2, cy2, rayon)
                    obstacle = False
    #   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -
            


            for w in SPARX.keys() :
                if encadrement_deux_sens(SPARX[w][0]-5,cx,SPARX[w][0]+5,True,True) and encadrement_deux_sens(SPARX[w][1]-5,cy,SPARX[w][1]+5,True,True) :    # Si l'un des Sparx entre en contact avec le joueur
                    Perdu = True

                if "Joueurs" in lst_variantes :
                    if encadrement_deux_sens(SPARX[w][0]-5,cx2,SPARX[w][0]+5,True,True) and encadrement_deux_sens(SPARX[w][1]-5,cy2,SPARX[w][1]+5,True,True) :
                        Perdu2 = True
                    for x in range(len(lst_coordonnees_curseur2)-1) :
                        if encadrement_deux_sens(lst_coordonnees_curseur2[x][0],cx,lst_coordonnees_curseur2[x+1][0],True,True) and encadrement_deux_sens(lst_coordonnees_curseur2[x][1],cy,lst_coordonnees_curseur2[x+1][1],True,True) :
                            Perdu = True
                    for x in range(len(lst_coordonnees_curseur)-1) :
                        if encadrement_deux_sens(lst_coordonnees_curseur[x][0],cx2,lst_coordonnees_curseur[x+1][0],True,True) and encadrement_deux_sens(lst_coordonnees_curseur[x][1],cy2,lst_coordonnees_curseur[x+1][1],True,True) :
                            Perdu2 = True

            if tev == "Quitte" :
                break


            mise_a_jour()
    



    #   * - * - * - * - * - * - * - * - * - * - * - * - * - * - * - * - * - *
    #   *                        Défaite / Victoire                         *
    #   * - * - * - * - * - * - * - * - * - * - * - * - * - * - * - * - * - *
        
            if zonetot >= zone_a_capture :
                niveau += 1
                if "Joueurs" in lst_variantes :
                    affichage_gagne(niveau, lst_variantes, zone_p1, zone_p2)
                    efface("curseur")
                    cx, cy, rayon = coin_sup_gauche[0], coin_inf_droite[1], lst_options[10] // 2
                    curseur(cx, cy, rayon)
                    cx2, cy2 = coin_inf_droite
                    curseur2(cx2, cy2, rayon)
                    efface("nbVies2")
                    draw2(0)
                    zone_p1, zone_p2 = 0, 0
                else :
                    affichage_gagne(niveau, lst_variantes)
                    efface('curseur')
                    cx, cy = largeurFenetre // 2, coin_inf_droite[1]
                    curseur(cx, cy, rayon)

                if "Obstacles" in lst_variantes :
                    efface("obstacles")
                    lst_obstacles = creation_obstacles(lst_options[0])

                if "Niveaux" in lst_variantes:
                    if niveau % lst_options[13] == 0 :
                        if zone_a_capture <= 99 :
                            zone_a_capture += lst_options[14]
                        nb_SPARX += 1
                    


                efface("Sparx")
                depSparx += lst_options[12]
                k = 0
                bascule = True
                for i in range(nb_SPARX) :
                    if i%2 == 0 :
                        k += 50
                    else :
                        k = -k
                    SPARX[i] = [(largeurFenetre // 2)+k, coin_sup_gauche[1], direc[i%2], bascule]
                    sparx(SPARX[i][0], SPARX[i][1])
                    bascule = not bascule


                efface("QIX")
                depQIX += lst_options[11]
                cxQIX = largeurFenetre // 2
                cyQIX = (coin_inf_droite[1] - coin_sup_gauche[1]) / 4 + coin_sup_gauche[1]
                carre(cxQIX - lst_options[9] // 2, cyQIX - lst_options[9] // 2, lst_options[9],"Red","Red","QIX",None)

                zonetot = 0
                efface("Trainée")
                efface("Zonecapturee")
                efface("nbVies")
                efface("Zone_a_capturee")
                efface("niveau")
                efface("score")
                draw(0, lst_variantes)
                update_act(zonetot, score, lst_variantes, zone_p1, zone_p2)
                efface("ZoneC")

                if "Joueurs" in lst_variantes:
                    efface("Trainée2")
                    dessiner2 = False
                    lst_coordonnees_curseur2 = []
                    coordonnees_debut2 = []

                else :
                    update_round(zone_a_capture,nbVies,niveau)
            
                dessiner = False
                lst_coordonnees_curseur = []
                coordonnees_debut = []
                coordonnees_debut_safezone = [[coin_inf_droite[0],coin_sup_gauche[1]],coin_sup_gauche]
                lst_coordonnees_safezone = [[coin_inf_droite[0],coin_sup_gauche[1]],coin_sup_gauche,[coin_sup_gauche[0],coin_inf_droite[1]],coin_inf_droite,[coin_inf_droite[0],coin_sup_gauche[1]],coin_sup_gauche]
                lst_coordonnees_polygones = [[coin_sup_gauche,[coin_inf_droite[0],coin_sup_gauche[1]],coin_inf_droite,[coin_sup_gauche[0],coin_inf_droite[1]]]]



            if Perdu is True :
                if "Joueurs" in lst_variantes :
                    nbVies -= 1
                    efface('curseur')
                    if coordonnees_debut != [] :
                        cx, cy = coordonnees_debut[0], coordonnees_debut[1]
                    curseur(cx, cy, rayon)
                    efface("nbVies")
                    efface("Trainée")
                    texte(120, 356, str(nbVies), "Violet", "center", police="Lucida Console", taille = 25, tag = "nbVies")
                    lst_coordonnees_curseur = []
                    coordonnees_debut = []
                    Perdu = False

                else :
                    nbVies -= 1
                    affichage_perdu(nbVies)
        
                    efface('curseur')
                    if coordonnees_debut != [] :
                        cx, cy = coordonnees_debut[0], coordonnees_debut[1]
                    curseur(cx, cy, rayon)
        
                    efface("Sparx")
                    k = 0
                    bascule = True
                    for i in range(nb_SPARX) :
                        if i%2 == 0 :
                            k += 50
                        else :
                            k = -k
                        SPARX[i] = [(largeurFenetre // 2)+k, coin_sup_gauche[1], direc[i%2], bascule]
                        sparx(SPARX[i][0], SPARX[i][1])
                        bascule = not bascule


                    efface("nbVies")
                    update_round(zone_a_capture,nbVies,niveau)
                    draw(0, lst_variantes)
                    dep = lst_options[4]

                    dessiner = False
                    lst_coordonnees_curseur = []
                    coordonnees_debut = []
                    Perdu = False
        
                    if nbVies == 0 :
                        break

            if Perdu2 is True and "Joueurs" in lst_variantes :
                nbVies2 -= 1
                efface('curseur')
                if coordonnees_debut2 != [] :
                    cx2, cy2 = coordonnees_debut2[0], coordonnees_debut2[1]
                curseur2(cx2, cy2, rayon)
                efface("nbVies2")
                efface("Trainée2")
                texte(920, 356, str(nbVies2), "Violet", "center", police="Lucida Console", taille = 25, tag = "nbVies2")
                lst_coordonnees_curseur2 = []
                coordonnees_debut2 = []
                Perdu2 = False

            if "Joueurs" in lst_variantes and (nbVies == 0 or nbVies2 == 0) :
                player = "Joueur 1" if nbVies2 == 0 else "Joueur 2"
                texte(largeurFenetre / 2, hauteurFenetre / 2 - 30, "Et le gagnant est ..." + str(player) + "!", "Gold", "center", police="Lucida Console", taille = 25, tag = "Gagner")
                mise_a_jour()
                attend_clic_gauche()
                break
            a += 1


        ferme_fenetre()
